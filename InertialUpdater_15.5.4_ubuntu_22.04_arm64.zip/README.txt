# MicroStrain Inertial Firmware Upgrader

This tool can be used to upgrade MicroStrain Inertial devices.

## Usage

Run the following command for more information on how to use this utility
```bash
InertialUpdater --help
```

## Dependencies

libpthread.so.0
libz.so.1
libstdc++.so.6
libm.so.6
libgcc_s.so.1
libc.so.6
